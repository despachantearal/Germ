function showFact() {
    const facts = [
        "Some bacteria help digest food!",
        "Not all germs are harmful.",
        "Your body has trillions of microbes.",
        "Microbes are essential to ecosystems."
    ];
    const random = Math.floor(Math.random() * facts.length);
    alert("🦠 " + facts[random]);
}
