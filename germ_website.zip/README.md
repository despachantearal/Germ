# 🦠 Microbe World Website

Simple germ-themed website project.

## Features
- Clean UI with science theme
- Random microbe facts
- Built with HTML, CSS, JavaScript

## How to Use
Open index.html in your browser.

## Author
Created for GitHub upload project.
